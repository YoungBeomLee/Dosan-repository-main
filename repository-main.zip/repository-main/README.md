제이쿼리-dom(Document Object Model)조작을 쉽게 할수 있게 개발된 자바스크립트 라이브러리

라이브러리를 사용하기 위한 조건

1. 라이브러리 파일을 불러온다(구글폰트)
2. 



=== 
### 스니펫 등록하기
1. ctrl+shift+P 
2. snippet
3. user snippet
4. html.json